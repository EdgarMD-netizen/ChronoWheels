"""
ChronoWheels Django project package.

This package marks the directory as a Python package and exposes default
application configuration. No additional code is needed here.
"""

__all__ = []  # explicit re-export nothing